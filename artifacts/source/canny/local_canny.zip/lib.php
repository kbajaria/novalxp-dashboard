<?php
// Local plugin for exposing Moodle user data to Canny.
// Place this folder as local/canny in your Moodle root.

defined('MOODLE_INTERNAL') || die();

/**
 * Callback executed before the page footer is printed.
 *
 * This lets us inject a small JS snippet that exposes the
 * current logged-in user's data to the browser as window.CANNY_USER.
 *
 * @return string HTML to append before </body>.
 */
function local_canny_before_footer() {
    global $USER;

    // Do not expose anything for guests or non-logged-in users.
    if (!isloggedin() || isguestuser()) {
        return '';
    }

    // Build a user data array for Canny.
    $userdata = [
        'id'        => (int)$USER->id,
        'email'     => (string)$USER->email,
        'name'      => fullname($USER),
        'avatarURL' => '',
        'created'   => (int)$USER->timecreated,
    ];

    // Try to construct a reasonable avatar URL if the user has a picture.
    if (!empty($USER->picture)) {
        require_once($GLOBALS['CFG']->libdir . '/weblib.php');
        $avatarurl = new moodle_url('/user/pix.php', ['id' => $USER->id, 'rev' => $USER->picture]);
        $userdata['avatarURL'] = $avatarurl->out(false);
    }

    // Safely JSON-encode for inline JS.
    $json = json_encode($userdata, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);

    // Output a small JS snippet that sets window.CANNY_USER.
    return '<script>window.CANNY_USER = ' . $json . ';</script>';
}
